export const drinks = [
  {name:"Midnight Old Fashioned",price:"$16",description:"Small-batch bourbon, smoked maple, aromatic bitters, orange oils.",position:"0% 0%"},
  {name:"Blackberry Smoke",price:"$15",description:"Mezcal, blackberry, rosemary, lime, a whisper of smoke.",position:"100% 0%"},
  {name:"Neon Margarita",price:"$14",description:"Blanco tequila, blood orange, agave, lime, sea salt.",position:"0% 100%"},
  {name:"Velvet Espresso Martini",price:"$17",description:"Vodka, cold brew, cacao, coffee liqueur, velvet foam.",position:"100% 100%"},
] as const;

export const events = [
  {day:"Friday",date:"OCT 16",name:"Live Jazz Night",time:"8:00 PM",description:"A late-evening quartet set with modern standards and low-lit lounge energy."},
  {day:"Saturday",date:"OCT 17",name:"DJ After Dark",time:"10:00 PM",description:"Disco, soul, and deep house selected for the room until close."},
  {day:"Thursday",date:"OCT 22",name:"Acoustic Sessions",time:"7:30 PM",description:"An intimate set from a featured singer-songwriter on the lounge stage."},
] as const;

export const menuSections = [
 {title:"Cocktails",items:[["The Golden Hour","Gin, bergamot, honey, lemon, sparkling wine","$16"],["Desert Bloom","Tequila, prickly pear, lime, chile","$15"],["House Highball","Japanese whisky, pear, soda","$14"],["Nocturne","Rye, amaro, coffee, bitters","$17"]]},
 {title:"Beer & Wine",items:[["Local Pale Ale","Crisp, bright, draft","$9"],["Japanese Lager","Clean and dry","$10"],["Brut Rosé","California, glass","$14"],["Pinot Noir","Willamette Valley, glass","$16"]]},
 {title:"Small Plates",items:[["Truffle Fries","Parmesan, herbs, roasted garlic aioli","$12"],["Crispy Chicken Sliders","Hot honey, pickles, brioche","$16"],["Charred Shishitos","Lime, smoked salt","$10"],["Chocolate Torte","Espresso cream, cacao nib","$13"]]},
 {title:"Coffee",items:[["Espresso","Single-origin double shot","$5"],["Cortado","Espresso, textured milk","$6"],["Cold Brew","House steeped, served over ice","$6"],["Affogato","Vanilla gelato, espresso","$9"]]},
] as const;