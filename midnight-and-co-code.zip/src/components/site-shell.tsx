import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Music2, Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const links = [
  ["Menu", "/menu"], ["Events", "/events"], ["Gallery", "/gallery"],
  ["About", "/about"], ["Reservations", "/reservations"], ["Contact", "/contact"],
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return <>
    <header className="glass-panel fixed inset-x-0 top-0 z-50 border-b border-border/60">
      <div className="page-shell flex h-18 items-center justify-between">
        <Link to="/" aria-label="Midnight and Company home" className="font-display text-xl font-semibold text-foreground sm:text-2xl">MIDNIGHT <span className="text-primary">&amp;</span> CO.</Link>
        <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary navigation">
          {links.map(([label, to]) => <Link key={to} to={to} activeProps={{className:"text-primary"}} className="text-[0.68rem] font-bold uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-foreground">{label}</Link>)}
        </nav>
        <div className="hidden sm:block"><Button asChild variant="luxe" size="lg"><Link to="/reservations">Reserve a table</Link></Button></div>
        <Button className="sm:hidden" variant="ghost" size="icon" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</Button>
      </div>
      {open && <nav className="border-t border-border bg-background px-5 py-5 sm:hidden" aria-label="Mobile navigation">{links.map(([label,to]) => <Link key={to} to={to} onClick={() => setOpen(false)} className="block border-b border-border py-3 text-sm uppercase tracking-[0.14em]">{label}</Link>)}</nav>}
    </header>
    <Button asChild variant="luxe" size="lg" className="fixed bottom-4 left-4 right-4 z-40 shadow-2xl sm:hidden"><Link to="/reservations">Reserve a table</Link></Button>
  </>;
}

export function SiteFooter() {
  return <footer className="border-t border-border bg-surface pb-24 pt-16 sm:pb-10">
    <div className="page-shell grid gap-12 md:grid-cols-[1.2fr_.8fr_.8fr]">
      <div><Link to="/" className="font-display text-3xl">MIDNIGHT <span className="text-primary">&amp;</span> CO.</Link><p className="mt-3 text-sm text-muted-foreground">Cocktails • Music • Late Nights</p><p className="mt-5 max-w-sm text-xs leading-6 text-muted-foreground">A fictional venue concept created as a portfolio demonstration. No real location or booking service is represented.</p></div>
      <div><p className="overline mb-4">Explore</p><div className="grid gap-2">{links.slice(0,5).map(([label,to]) => <Link key={to} to={to} className="text-sm text-muted-foreground hover:text-primary">{label}</Link>)}</div></div>
      <div><p className="overline mb-4">Social</p><div className="flex gap-3"><a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram" className="rounded-full border border-border p-3 text-muted-foreground hover:border-primary hover:text-primary"><Instagram className="size-4"/></a><a href="https://facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook" className="rounded-full border border-border p-3 text-muted-foreground hover:border-primary hover:text-primary"><Facebook className="size-4"/></a><a href="https://tiktok.com" target="_blank" rel="noreferrer" aria-label="TikTok" className="rounded-full border border-border p-3 text-muted-foreground hover:border-primary hover:text-primary"><Music2 className="size-4"/></a></div></div>
    </div>
    <div className="page-shell mt-14 border-t border-border pt-6 text-[0.65rem] uppercase tracking-[0.14em] text-muted-foreground">© 2026 Midnight &amp; Co. — Fictional demo concept</div>
  </footer>;
}