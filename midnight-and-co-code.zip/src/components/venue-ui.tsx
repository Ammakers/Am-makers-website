import { Link } from "@tanstack/react-router";
import { useState, type FormEvent, type ReactNode } from "react";
import { ArrowRight, Check, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function SectionHead({ eyebrow, title, copy, action }: { eyebrow: string; title: string; copy?: string; action?: ReactNode }) {
  return <div className="mb-10 flex flex-col justify-between gap-5 sm:mb-14 md:flex-row md:items-end"><div><p className="overline mb-3">{eyebrow}</p><h2 className="max-w-3xl text-4xl leading-none sm:text-5xl lg:text-6xl">{title}</h2>{copy && <p className="mt-5 max-w-xl text-sm leading-7 text-muted-foreground">{copy}</p>}</div>{action}</div>;
}

export function DemoNote({ children }: { children: ReactNode }) { return <p className="inline-flex items-center gap-2 border border-border bg-surface-raised px-3 py-2 text-[0.62rem] font-bold uppercase tracking-[0.15em] text-muted-foreground"><span className="size-1.5 rounded-full bg-primary"/>{children}</p>; }

export function PageHero({ eyebrow, title, copy, image }: { eyebrow:string; title:string; copy:string; image:string }) {
  return <section className="relative min-h-[68vh] overflow-hidden pt-18"><img src={image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-55" width={1536} height={1024}/><div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent"/><div className="page-shell relative flex min-h-[calc(68vh-4.5rem)] items-end py-16"><div className="max-w-3xl reveal-up"><p className="overline mb-5">{eyebrow}</p><h1 className="text-6xl leading-[.86] sm:text-7xl lg:text-8xl">{title}</h1><p className="mt-7 max-w-xl text-base leading-7 text-muted-foreground sm:text-lg">{copy}</p></div></div></section>;
}

export function ReservationForm() {
  const [sent,setSent] = useState(false);
  function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setSent(true)}
  if(sent) return <div role="status" className="flex min-h-80 flex-col items-center justify-center border border-primary/40 bg-surface p-8 text-center"><span className="mb-5 rounded-full border border-primary p-3 text-primary"><Check className="size-6"/></span><h3 className="text-3xl">Thanks!</h3><p className="mt-3 text-muted-foreground">This is a demo reservation request.</p><Button variant="luxeOutline" className="mt-7" onClick={()=>setSent(false)}>Make another request</Button></div>;
  return <form onSubmit={submit} className="grid gap-5" aria-label="Demo reservation request">
    <DemoNote>Demo only — no booking will be processed</DemoNote>
    <div className="grid gap-5 sm:grid-cols-3"><Field label="Date"><Input required type="date"/></Field><Field label="Time"><select required defaultValue="" className="h-12 w-full rounded-sm border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"><option value="" disabled>Select time</option><option>7:00 PM</option><option>8:30 PM</option><option>10:00 PM</option><option>11:30 PM</option></select></Field><Field label="Guests"><select required defaultValue="" className="h-12 w-full rounded-sm border border-input bg-background px-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-ring"><option value="" disabled>Party size</option>{[1,2,3,4,5,6,7,8].map(n=><option key={n}>{n} {n===1?'guest':'guests'}</option>)}</select></Field></div>
    <div className="grid gap-5 sm:grid-cols-3"><Field label="Name"><Input required placeholder="Your name"/></Field><Field label="Email"><Input required type="email" placeholder="you@example.com"/></Field><Field label="Phone"><Input required type="tel" placeholder="(000) 000-0000"/></Field></div>
    <Button type="submit" variant="luxe" size="lg" className="mt-2 w-full sm:w-fit">Request reservation <ArrowRight/></Button>
  </form>;
}
function Field({label,children}:{label:string;children:ReactNode}) { return <label className="grid gap-2 text-[0.66rem] font-bold uppercase tracking-[0.14em] text-muted-foreground"><span>{label}</span>{children}</label> }

export function LocationBlock(){return <section className="bg-surface py-20 sm:py-28"><div className="page-shell grid overflow-hidden border border-border lg:grid-cols-2"><div className="p-8 sm:p-12"><MapPin className="mb-7 text-primary"/><p className="overline">Find the night</p><h2 className="mt-3 text-5xl">Midnight &amp; Co.</h2><p className="mt-5 text-muted-foreground">Downtown Las Vegas, Nevada</p><div className="mt-10 grid gap-3 text-sm"><p className="flex justify-between border-b border-border pb-3"><span>Mon–Thu</span><span className="text-muted-foreground">5 PM – 1 AM</span></p><p className="flex justify-between border-b border-border pb-3"><span>Fri–Sat</span><span className="text-muted-foreground">5 PM – 2 AM</span></p><p className="flex justify-between"><span>Sunday</span><span className="text-muted-foreground">5 PM – 12 AM</span></p></div><p className="mt-8 text-xs leading-5 text-muted-foreground">Fictional location details for demonstration purposes only.</p></div><div className="relative min-h-96 overflow-hidden bg-muted" aria-label="Stylized map placeholder"><div className="map-grid absolute inset-0 opacity-30"/><div className="absolute left-[48%] top-[45%] flex -translate-x-1/2 -translate-y-1/2 flex-col items-center"><div className="rounded-full border border-primary bg-background p-4 text-primary shadow-2xl"><MapPin/></div><span className="mt-3 bg-background px-3 py-2 text-[0.6rem] font-bold uppercase tracking-[.15em]">Downtown · Demo</span></div></div></div></section>}

export function TextLink({to,children}:{to:"/menu"|"/events"|"/gallery"|"/about"|"/reservations"|"/contact";children:ReactNode}) { return <Link to={to} className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[.14em] text-primary hover:gap-3">{children}<ArrowRight className="size-4"/></Link> }